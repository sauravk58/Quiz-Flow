clc;
clear all;
close all;

syms t; % Define symbolic variable

v = -5:1:5; % Define range for v

% Compute Fresnel Complex Integral F(v)
F_v = arrayfun(@(v_val) double(int(exp(-1j * pi * t^2 / 2), t, v_val, inf)), v);

% Compute Diffraction Gain (in dB)
G_d = 20 * log10(abs((1 + 1j) / 2 .* F_v));

% Plot results
figure;
plot(v, G_d, 'b', 'LineWidth', 2);
xlabel('v');
ylabel('G_d (dB)');
title('Fresnel Diffraction Gain vs v');
grid on;


