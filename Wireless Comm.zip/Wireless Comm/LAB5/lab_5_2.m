clc;
clear all;
close all;

syms t; % Define symbolic variable

v = -5:0.1:5; % Define a finer range for smooth plotting
G_d_piecewise = zeros(size(v)); % Initialize G_d_piecewise

% Compute Fresnel Integral-Based Diffraction Gain
F_v = arrayfun(@(v_val) double(int(exp(-1j * pi * t^2 / 2), t, v_val, inf)), v);
G_d_fresnel = 20 * log10(abs((1 + 1j) / 2 .* F_v)); 

% Compute Piecewise Diffraction Gain
G_d_piecewise(v <= -1) = 0; % G_d_0 for v <= -1
G_d_piecewise((-1 < v) & (v <= 0)) = 20*log10(0.5 - 0.62.*v((-1 < v) & (v <= 0))); % G_d_1 for -1 < v <= 0
G_d_piecewise((0 < v) & (v <= 1)) = 20*log10(0.5 * exp(-0.95 * v((0 < v) & (v <= 1)))); % G_d_2 for 0 < v <= 1
G_d_piecewise((1 < v) & (v <= 2.4)) = 20*log10(0.4 - sqrt(0.1184 - (0.38 - 0.1*v((1 < v) & (v <= 2.4))).^2)); % G_d_3 for 1 < v <= 2.4
G_d_piecewise(v > 2.4) = 20*log10(0.225 ./ v(v > 2.4)); % G_d_4 for v > 2.4

% Plot results
figure;
plot(v, G_d_fresnel, 'r', 'LineWidth', 2); % Plot Fresnel Integral Diffraction Gain in Red
hold on;
plot(v, G_d_piecewise, 'b--', 'LineWidth', 2); % Plot Piecewise Diffraction Gain in Blue (Dashed)
hold off;

xlabel('v');
ylabel('G_d (dB)');
title('Comparison of Diffraction Gain Methods');
legend('Fresnel Integral-Based', 'Piecewise Defined', 'Location', 'Best');
grid on;
