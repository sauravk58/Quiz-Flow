clc;
clear all;
close all;

% Define parameters of Uniform distribution
lower = 0; % Lower bound
upper = 1; % Upper bound

lower1 = 2;
upper1 = 5;

lower2 = -3;
upper2 = 2;

% Generate random samples from the Uniform distribution
sample_size = 1000;
random_samples = lower + (upper - lower) * rand(sample_size, 1);

% Compute the PDF and CDF
x = linspace(-4, 6, 1000);
pdf_values = (x >= lower & x <= upper) * (1 / (upper - lower));
cdf_values = (x >= lower & x <= upper) .* ((x - lower) / (upper - lower)) + (x > upper);

% Plot the PDF
figure;
plot(x, pdf_values, 'b-', 'LineWidth', 2, 'DisplayName', ['[' num2str(lower) ', ' num2str(upper) ']']);
hold on;
pdf_values1 = (x >= lower1 & x <= upper1) * (1 / (upper1 - lower1));
cdf_values1 = (x >= lower1 & x <= upper1) .* ((x - lower1) / (upper1 - lower1)) + (x > upper1);
plot(x, pdf_values1, 'g-', 'LineWidth', 2, 'DisplayName', ['[' num2str(lower1) ', ' num2str(upper1) ']']);

pdf_values2 = (x >= lower2 & x <= upper2) * (1 / (upper2 - lower2));
cdf_values2 = (x >= lower2 & x <= upper2) .* ((x - lower2) / (upper2 - lower2)) + (x > upper2);
plot(x, pdf_values2, 'r-', 'LineWidth', 2, 'DisplayName', ['[' num2str(lower2) ', ' num2str(upper2) ']']);

title('Probability Density Function (PDF) of Uniform Distribution');
xlabel('Random Variable(X)');
ylabel('PDF f(x)');
grid on;
legend show;

% Plot the CDF
figure;
plot(x, cdf_values, 'b-', 'LineWidth', 2, 'DisplayName', ['[' num2str(lower) ', ' num2str(upper) ']']);
hold on;
plot(x, cdf_values1, 'g-', 'LineWidth', 2, 'DisplayName', ['[' num2str(lower1) ', ' num2str(upper1) ']']);
plot(x, cdf_values2, 'r-', 'LineWidth', 2, 'DisplayName', ['[' num2str(lower2) ', ' num2str(upper2) ']']);

title('Cumulative Distribution Function (CDF) of Uniform Distribution');
xlabel('Random Variable(X)');
ylabel('CDF F(x)');
grid on;
legend show;