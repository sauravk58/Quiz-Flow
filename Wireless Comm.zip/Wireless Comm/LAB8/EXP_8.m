clc;
clear all; close all;

N = 10^6; % Number of bits or symbols


% Transmitter
ip = rand(1, N) > 0.5; % Generating 0,1 with equal probability 
s = 2 * ip - 1; % BPSK modulation: 0 -> -1, 1 -> +1

Eb_N0_dB = -3:35; % Eb/N0 range in dB
EbN0Lin = 10.^(Eb_N0_dB / 10); % Linear scale


% Analytical BER for AWGN (using Q-function) 
BER_AWGN = qfunc(sqrt(2 * EbN0Lin));

% Analytical BER for Rayleigh (using theoretical formula) 
BER_Rayleigh = 0.5 * (1 - sqrt(EbN0Lin ./ (EbN0Lin + 1)));

% Plotting the results 
figure;
semilogy(Eb_N0_dB, BER_AWGN, 'bo-', 'LineWidth', 2); % AWGN BER 
hold on;
semilogy(Eb_N0_dB, BER_Rayleigh, 'r^-', 'LineWidth', 2); % Rayleigh BER


% Plot settings grid on;
axis([-3 35 10^-6 0.5]);
legend('AWGN (Analytical)', 'Rayleigh (Analytical)', 'Location', 'Best'); 
xlabel('Eb/No (dB)');
ylabel('Bit Error Rate (BER)');
title('BER vs. Eb/No for Rayleigh and AWGN Channels (Analytical)');
