clc
clear all
close all
a=4;
b=4;
if (a==b)
    disp('YES');
end

b=6;   
if (a==b)
    disp('YES');
 
else
    disp('NO'); 
end

% Call the user-defined function add1
x1 = add1(1, 2); % Adding 1 and 2
fprintf('The sum of 1 and 2 is: %d\n', x1);

x2 = add1(5, 7); % Adding 5 and 7
fprintf('The sum of 5 and 7 is: %d\n', x2);


 % for and while loops %
 % Example: Calculate and display the square of numbers from 1 to 5
for i = 1:5
    square = i^2; % Calculate square of the number
    fprintf('The square of %d is %d\n', i, square);
end

% Example: Sum numbers until the sum exceeds 20
sumValue = 0;
i = 1;
while sumValue <= 20
    sumValue = sumValue + i;
    fprintf('Adding %d, total sum is %d\n', i, sumValue);
    i = i + 1; % Increment the counter
end



 
         
x = add1(1,2);
x = add1(5,7);