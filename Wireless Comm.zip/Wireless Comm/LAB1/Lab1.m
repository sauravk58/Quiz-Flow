clear all
close all
m = [ pi exp(pi); 0 1]

m = [ pi exp(pi); 0 1];

a = pi

m(1,2)

elem = m(1,2)
 
row=m(1,:)

col = m(:,1)

n = m'

p = [ 3 4; 5 6; 7 8];

eye(3);

eye(0);

zeros(3);

 
ans*p;

p*n;

p + n;
m + n;

m - n;

prod_ele = m.*p;
 
prod_ele = m.*n;

x = add1(1,2);

