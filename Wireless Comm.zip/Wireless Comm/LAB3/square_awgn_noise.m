% Parameters
Fs = 1000;                  % Sampling frequency
T = 1;                      % Signal duration
t = 0:1/Fs:T-1/Fs;          % Time vector

f_signal = 10;              % Frequency of square wave
A_signal = 1;               % Amplitude

% Manually generating a square wave using the sign function
signal = A_signal * sign(sin(2 * pi * f_signal * t));

% Plot signal
figure;
subplot(4,1,1);
plot(t, signal);
title('Original Signal');

% Noise generation
SNR_dB = 0;
noise_power = var(signal) / (10^(SNR_dB/10));
noise = sqrt(noise_power) * randn(size(t));

% Add noise to the signal
noisy_signal = signal + noise;

subplot(4,1,2);
plot(t, noisy_signal);
title(['Noisy Signal (SNR = ' num2str(SNR_dB) ' dB)']);
xlabel('Time (seconds)');
