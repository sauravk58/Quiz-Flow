clc; clear all; close all;

% Parameters
Fs = 1000;                  % Sampling frequency
T = 1;                      % Duration in seconds
t = 0:1/Fs:T-1/Fs;          % Time vector

f_signal = 10;              % Frequency of sinusoidal signal
A_signal = 1;               % Amplitude

% Generate sinusoidal signal
signal = A_signal * sin(2*pi*f_signal*t);

% Define SNR in dB
SNR_dB = 0;

% Compute theoretical signal power
signal_power = (A_signal^2) / 2;  % Power of sinusoidal signal

% Compute noise power based on SNR
noise_power = signal_power / (10^(SNR_dB/10));

% Generate AWGN noise with desired power
noise = sqrt(noise_power) * randn(size(t));

% Add noise to the signal
noisy_signal = signal + noise;

% Plot results
figure;
subplot(2,1,1);
plot(t, signal);
title('Original Signal');

subplot(2,1,2);
plot(t, noisy_signal);
title(['Noisy signal (SNR = ' num2str(SNR_dB) ' dB)']);
xlabel('Time (seconds)');

% Verify power levels
computed_signal_power = var(signal);
computed_noise_power = var(noise);
disp(['Signal Power: ', num2str(computed_signal_power)]);
disp(['Noise Power: ', num2str(computed_noise_power)]);
