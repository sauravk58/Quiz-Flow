% Given data
delay_us = [0, 1, 3, 5];           % microseconds
power_dB = [-20, -10, 0, -10];     % dB

% Convert power from dB to linear scale
power_linear = 10.^(power_dB / 10);


% ---- T1: Plot Power Delay Profile ----
figure;
stem(delay_us, power_dB, 'filled');
xlabel('Delay (\mus)');
ylabel('Power (dB)');
title('Power Delay Profile');
grid on;

% ---- T2: Calculate Channel Metrics ----
% Mean delay
mean_delay = sum(delay_us .* power_linear) / sum(power_linear);

% RMS Delay Spread = sqrt(mean square delay - (mean delay)^2)
rms_delay_spread = sqrt(sum(power_linear.*(delay_us - mean_delay).^2)/sum(power_linear));

% Delay Spread = max delay - min delay
delay_spread = max(delay_us) - min(delay_us);

% Output results
fprintf('Mean Delay (us): %.4f\n', mean_delay);
fprintf('RMS Delay Spread (us): %.4f\n', rms_delay_spread);
fprintf('Delay Spread (us): %.4f\n', delay_spread);
